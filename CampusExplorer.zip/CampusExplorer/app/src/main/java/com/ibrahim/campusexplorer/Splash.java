package com.ibrahim.campusexplorer;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;

public class Splash extends AppCompatActivity
{

    Animation anim;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        String firstStart = prefs.getString("name","");
        boolean check = false;
        if (firstStart.equals("")) {
            check = true;
            Log.i("true", "inside");
        }


        imageView = (ImageView) findViewById(R.id.imageView2); // Declare an imageView to show the animation.
        anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in); // Create the animation.
        final boolean finalCheck = check;
        anim.setAnimationListener(new Animation.AnimationListener()
        {
            @Override
            public void onAnimationStart(Animation animation)
            {
            }

            @Override
            public void onAnimationEnd(Animation animation)
            {
                if(finalCheck == true)
                {
                    startActivity(new Intent(Splash.this, getNameActivity.class));
                    // HomeActivity.class is the activity to go after showing the splash screen.
                    finish();
                }
                else
                {
                    startActivity(new Intent(Splash.this, MainActivity.class));
                    // HomeActivity.class is the activity to go after showing the splash screen.
                    finish();
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation)
            {
            }
        });
        imageView.startAnimation(anim);



    }

}
